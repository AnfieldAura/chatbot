import React, { useState, KeyboardEvent, FormEvent } from 'react';
import { Bell, History, Menu, User, Send } from 'lucide-react';

interface Message {
  text: string;
  sender: 'bot' | 'user';
  timestamp: Date;
}

interface QuickReply {
  text: string;
  action: () => void;
}

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      text: "Hello! Select one of the queries given below that fits your needs.",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [showSidebar, setShowSidebar] = useState(true);

  const quickReplies: QuickReply[] = [
    { text: "Admission Process", action: () => handleQuickReply("Tell me about admissions") },
    { text: "Course Information", action: () => handleQuickReply("What courses are offered?") },
    { text: "Faculty Details", action: () => handleQuickReply("Show faculty information") },
    { text: "Campus Facilities", action: () => handleQuickReply("What facilities are available?") },
    { text: "Placements", action: () => handleQuickReply("Tell me about placements") },
    { text: "Contact Info", action: () => handleQuickReply("How can I contact the college?") }
  ];

  const handleQuickReply = (text: string) => {
    // Add user message
    setMessages(prev => [...prev, {
      text,
      sender: 'user',
      timestamp: new Date()
    }]);

    // Simulate bot response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        text: `Here's information about: ${text}`,
        sender: 'bot',
        timestamp: new Date()
      }]);
    }, 1000);
  };

  const handleSubmit = (e?: FormEvent) => {
    e?.preventDefault();
    
    if (!inputText.trim()) return;

    // Add user message
    setMessages(prev => [...prev, {
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    }]);

    // Clear input
    setInputText('');

    // Simulate bot response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        text: `I received your message: "${inputText}"`,
        sender: 'bot',
        timestamp: new Date()
      }]);
    }, 1000);
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Dashboard Sidebar */}
      {showSidebar && (
        <div className="w-64 bg-gray-900 text-white p-6">
          <h1 className="text-2xl font-bold mb-8">DASHBOARD</h1>
          <div className="space-y-6">
            <div className="bg-gray-800 p-4 rounded-lg h-48"></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-800 p-4 rounded-lg h-24"></div>
              <div className="bg-gray-800 p-4 rounded-lg h-24"></div>
            </div>
            <div className="bg-gray-800 p-4 rounded-lg h-48"></div>
          </div>
        </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation */}
        <div className="bg-gray-900 text-white p-4 flex justify-between items-center">
          <button onClick={() => setShowSidebar(!showSidebar)}>
            <Menu className="h-6 w-6" />
          </button>
          <h1 className="text-3xl font-bold">ALIGN</h1>
          <div className="flex gap-4">
            <Bell className="h-6 w-6" />
            <User className="h-6 w-6" />
          </div>
        </div>

        {/* Chat Container */}
        <div className="flex-1 flex">
          {/* Main Chat */}
          <div className="flex-1 flex flex-col p-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-4">I AM YOUR COLLEGE CHATBOT!</h2>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto mb-6">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`mb-4 ${msg.sender === 'bot' ? 'text-center' : 'text-right'}`}
                >
                  <div
                    className={`inline-block p-3 rounded-lg ${
                      msg.sender === 'bot'
                        ? 'bg-gray-200'
                        : 'bg-blue-500 text-white'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Input Form */}
            <form onSubmit={handleSubmit} className="mb-6">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message..."
                  className="flex-1 p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="submit"
                  className="bg-blue-500 text-white p-3 rounded-lg hover:bg-blue-600 transition"
                >
                  <Send className="h-6 w-6" />
                </button>
              </div>
            </form>

            {/* Quick Replies */}
            <div className="grid grid-cols-3 gap-4">
              {quickReplies.map((reply, idx) => (
                <button
                  key={idx}
                  onClick={reply.action}
                  className="bg-gray-800 text-white p-3 rounded-lg hover:bg-gray-700 transition"
                >
                  {reply.text}
                </button>
              ))}
            </div>
          </div>

          {/* History Sidebar */}
          <div className="w-64 bg-gray-900 text-white p-6">
            <h2 className="text-xl font-bold mb-6">HISTORY</h2>
            <div className="space-y-4">
              {messages.slice(-5).map((msg, idx) => (
                <div key={idx} className="bg-gray-800 p-3 rounded-lg">
                  <p className="text-sm">{msg.text}</p>
                  <p className="text-xs text-gray-400 mt-1">
                    {msg.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;